public interface Validate {
    boolean validateName(String name);
}