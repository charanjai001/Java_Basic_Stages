// WRITE YOUR CODE HERE
$("p").css({"color":"orange"});
$("p:nth-child(2)").css({"font-size":"50%"});
$(".flavours  li").css({"background-color":"lightblue","font-size":"120%"});
$("#icecreamfloats li").css({"background-color":"orange"});
