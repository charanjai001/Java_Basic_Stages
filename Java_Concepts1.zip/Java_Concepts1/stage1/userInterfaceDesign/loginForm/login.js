//WRITE YOUR JQUERY CODE HERE
$("#signup_div").fadeOut()
$('#signup').click(function(){
    $("#home").fadeOut()
    $("#signup_div").fadeIn() 
})